# Please give us feedback to help us improve the exercises.

## Major Problems?

## Helpful?

## Duration (hours)?

*Please make a list where every student in your group puts in the hours they used to do the complete exercise Example: [5.5, 4, 7], if one of you took 5 and a half hours, one person 4 and the other 7. The order does not matter. This feedback will help us analyze which exercise sheets are too time-intensive.*

[]

## Other feedback?

