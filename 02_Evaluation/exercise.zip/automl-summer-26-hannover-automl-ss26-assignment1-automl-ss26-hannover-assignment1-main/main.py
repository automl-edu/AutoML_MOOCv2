"""
main.py -- Assignment 1: Evaluation and Benchmarking
=========================================================
AutoML MOOC  |  Chapter 2

Usage
-----
    python main.py

All figures are saved to the figures/ directory. This should be committed to your repository.
Written answers go into answers.pdf (separate document).
"""

import os

import matplotlib
matplotlib.use("Agg")  # non-interactive backend for saving figures
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.tree import DecisionTreeClassifier

os.makedirs("figures", exist_ok=True)

ALPHA = 0.05  # significance level used throughout


# ===========================================================
# Data loaders
# ===========================================================

def load_classification_data():
    """Load classification dataset.

    Returns
    -------
    X : ndarray, shape (500, 10)
    y : ndarray, shape (500,), binary labels
    """
    df = pd.read_csv("data/classification_data.csv")
    X = df.drop(columns=["y"]).values
    y = df["y"].values
    return X, y


def load_automl_configs():
    """Load AutoML configuration evaluation results.

    Returns
    -------
    DataFrame with columns ['val_error', 'test_error'], 200 rows.
    """
    return pd.read_csv("data/automl_configs.csv")


def load_pairwise_results():
    """Load per-dataset errors for two AutoML systems.

    Returns
    -------
    DataFrame with columns ['System_A', 'System_B'], 30 rows.
    """
    return pd.read_csv("data/pairwise_results.csv")


def load_multi_system_results():
    """Load per-dataset errors for five AutoML systems.

    Returns
    -------
    DataFrame with columns ['System_1', ..., 'System_5'], 20 rows.
    """
    return pd.read_csv("data/multi_system_results.csv")


def load_anytime_logs():
    """Load anytime performance logs.

    Returns
    -------
    DataFrame with columns ['system', 'seed', 'wall_time', 'incumbent_error'].
    Each row is one improvement event.
    """
    return pd.read_csv("data/anytime_logs.csv")


# ===========================================================
# Exercise 1: Resampling Strategies
# ===========================================================

def exercise_1():
    """Resampling Strategies (4 pts)."""
    print("=" * 60)
    print("Exercise 1: Resampling Strategies")
    print("=" * 60)

    X, y = load_classification_data()
    clf = DecisionTreeClassifier(random_state=0)

    # ----------------------------------------------------------
    # Part (a) -- Hold-Out, 5-Fold CV, MCCV
    # ----------------------------------------------------------

    # --- Hold-Out (80/20 stratified) ---
    # TODO: Split X, y into train/test using train_test_split with
    #       test_size=0.2, stratify=y, random_state=0.
    #       Fit clf on the training set and compute error on the test set.
    #       error = 1 - accuracy
    # ----------------------------------------------------------------
    holdout_mean = None  # replace with computed mean
    holdout_std = 0.0    # single split -> std is 0 by definition
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    if holdout_mean is not None:
        print(f"Hold-Out  | mean error: {holdout_mean:.2f} | std: {holdout_std:.2f}")

    # --- 5-Fold Stratified Cross-Validation ---
    # TODO: Implement k-fold cross validation with 5 folds.
    #       For each fold, fit clf on the training part and evaluate on the
    #       held-out fold.  Collect one error per fold.
    # ----------------------------------------------------------------
    cv5_scores = []  # list of per-fold errors
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    cv5_mean = np.mean(cv5_scores) if cv5_scores else None
    cv5_std = np.std(cv5_scores, ddof=1) if len(cv5_scores) > 1 else None
    if cv5_mean is not None:
        print(f"5-Fold CV | mean error: {cv5_mean:.2f} | std: {cv5_std:.2f}")

    # --- Monte-Carlo Cross-Validation (R=30) ---
    # TODO: Run 30 independent random 80/20 stratified splits.
    #       Use random_state=r for the r-th repetition (r = 0, 1, ..., 29).
    #       Collect one error per split.
    # ----------------------------------------------------------------
    mccv_scores = []  # list of per-split errors
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    mccv_mean = np.mean(mccv_scores) if mccv_scores else None
    mccv_std = np.std(mccv_scores, ddof=1) if len(mccv_scores) > 1 else None
    if mccv_mean is not None:
        print(f"MCCV      | mean error: {mccv_mean:.2f} | std: {mccv_std:.2f}")

    # ----------------------------------------------------------
    # Part (b) -- MCCV variance as a function of R
    # ----------------------------------------------------------
    R_values = [5, 10, 20, 30, 50, 100]

    # TODO: For each R in R_values, run R random splits (random_state=r
    #       for the r-th split) and record the std of the R error scores.
    #       Store the stds in a list `stds`.
    # ----------------------------------------------------------------
    stds = []  # one std value per R
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    # Plot std vs R
    fig, ax = plt.subplots()
    # TODO: Replace the placeholder below with your actual plot.
    #       Use ax.plot(R_values, stds, marker='o').
    #       Label axes and add a title.
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    ax.set_xlabel("Number of MCCV repetitions R")
    ax.set_ylabel("Std of error estimate")
    ax.set_title("MCCV variance vs. number of repetitions")
    # ----------------------------------------------------------------
    fig.savefig("figures/mccv_variance.pdf", bbox_inches="tight")
    plt.close(fig)
    print("  -> figures/mccv_variance.pdf saved.")

    # ----------------------------------------------------------------
    # Discussion (place answer in answers.pdf):
    # Q: What trend do you observe, and why does it occur?
    # ----------------------------------------------------------------

    return (holdout_mean, holdout_std), (cv5_mean, cv5_std), (mccv_mean, mccv_std)


# ===========================================================
# Exercise 2: The Optimistic Bias in AutoML
# ===========================================================

def exercise_2():
    """The Optimistic Bias in AutoML (3 pts)."""
    print("\n" + "=" * 60)
    print("Exercise 2: Optimistic Bias in AutoML")
    print("=" * 60)

    df = load_automl_configs()
    val_errors = df["val_error"].values   # shape (200,)
    test_errors = df["test_error"].values  # shape (200,)

    t_values = [1, 5, 10, 20, 50, 100, 200]

    # ----------------------------------------------------------
    # Part (a) -- Val/test error and bias for each prefix t
    # ----------------------------------------------------------
    val_bests = []
    test_bests = []

    for t in t_values:
        # TODO: Among the first t configurations (val_errors[:t]):
        #       1. Find i* = argmin(val_errors[:t])
        #       2. val_best  = val_errors[i*]
        #       3. test_best = test_errors[i*]
        #       4. bias      = test_best - val_best
        #       5. Print in the required format (4 decimal places).
        # ------------------------------------------------------------
        val_best = None   # replace
        test_best = None  # replace
        bias = None       # replace
        # ----------------------------------------------------------------
        # =================================================================
        # YOUR CODE HERE




        # =================================================================
        # ----------------------------------------------------------------
        val_bests.append(val_best)
        test_bests.append(test_best)
        if None not in (val_best, test_best, bias):
            print(f"t={t:>4d} | val error: {val_best:.4f} | "
                  f"test error: {test_best:.4f} | bias: {bias:+.4f}")

    # ----------------------------------------------------------
    # Part (b) -- Plot val and test error vs t (log x-axis)
    # ----------------------------------------------------------
    fig, ax = plt.subplots()
    # TODO: Plot val_bests and test_bests as lines over t_values.
    #       Use ax.set_xscale("log") for the log x-axis.
    #       Label axes, add a legend, add a title.
    # ------------------------------------------------------------
    # YOUR CODE HERE
    ax.set_xscale("log")
    ax.set_xlabel("Number of evaluated configurations t")
    ax.set_ylabel("Error")
    ax.set_title("Optimistic bias as a function of t")
    ax.legend()
    # ------------------------------------------------------------
    fig.savefig("figures/optimistic_bias.pdf", bbox_inches="tight")
    plt.close(fig)
    print("  -> figures/optimistic_bias.pdf saved.")

    # ----------------------------------------------------------------
    # Discussion (place answer in answers.pdf):
    # Q1: What do you observe as t grows? Why does this happen?
    # Q2: How does nested evaluation address this problem?
    # ----------------------------------------------------------------


    return val_bests, test_bests, bias


# ===========================================================
# Exercise 3: Statistical Tests -- Pairwise Comparisons
# ===========================================================

def wilcoxon_signed_rank(errors_a, errors_b):
    """Two-sided Wilcoxon Signed-Rank Test (implemented from scratch).

    Parameters
    ----------
    errors_a, errors_b : array-like of length n
        Per-dataset errors of System A and System B.

    Returns
    -------
    W : float
        Test statistic min(W+, W-).
    p_value : float
        Two-sided p-value via normal approximation.
    """
    errors_a = np.asarray(errors_a, dtype=float)
    errors_b = np.asarray(errors_b, dtype=float)

    # Step 1: Compute signed differences; discard ties
    # TODO: d = errors_a - errors_b; remove entries where d == 0.
    d = None  # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    # Step 2: Rank absolute differences (average ranks for ties)
    # TODO: Rank |d| using scipy.stats.rankdata with method='average'.
    abs_ranks = None  # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    # Step 3: Compute W+, W-, W
    # TODO: W_plus  = sum of ranks where d > 0
    #       W_minus = sum of ranks where d < 0
    #       W       = min(W_plus, W_minus)
    W_plus = None   # replace
    W_minus = None  # replace
    W = None        # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    # Step 4: Normal approximation
    # TODO: n_prime = number of non-tied pairs (len of d after removing ties)
    #       mu_W    = n_prime * (n_prime + 1) / 4
    #       sigma_W = sqrt(n_prime * (n_prime + 1) * (2*n_prime + 1) / 24)
    #       z       = (W - mu_W) / sigma_W
    #       p_value = 2 * stats.norm.sf(abs(z))   [two-sided]
    p_value = None  # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    return W, p_value


def corrected_resampled_t_test(errors_a, errors_b, k=5):
    """Corrected resampled t-test (Nadeau & Bengio 2003).

    Parameters
    ----------
    errors_a, errors_b : array-like of length n
        Per-dataset errors.
    k : int
        Number of CV folds used to produce the errors (default 5).

    Returns
    -------
    t_stat : float
    p_value : float (two-sided)
    """
    errors_a = np.asarray(errors_a, dtype=float)
    errors_b = np.asarray(errors_b, dtype=float)
    n = len(errors_a)

    # TODO:
    # 1. d_i     = errors_a[i] - errors_b[i]
    # 2. d_bar   = mean(d)
    # 3. s2      = var(d, ddof=1)
    # 4. Corrected variance:
    #      s2_corr = (1/n + 1/(k-1)) * s2
    #    This accounts for the correlation between MCCV/CV folds.
    # 5. t_stat  = d_bar / sqrt(s2_corr)
    # 6. p_value = 2 * stats.t.sf(|t_stat|, df=n-1)   [two-sided]
    t_stat = None   # replace
    p_value = None  # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    return t_stat, p_value


def exercise_3():
    """Statistical Tests: Pairwise Comparisons (4 pts)."""
    print("\n" + "=" * 60)
    print("Exercise 3: Statistical Tests (Pairwise)")
    print("=" * 60)

    df = load_pairwise_results()
    errors_a = df["System_A"].values
    errors_b = df["System_B"].values

    # ----------------------------------------------------------
    # Part (a) -- Wilcoxon Signed-Rank Test (from scratch)
    # ----------------------------------------------------------
    W, p_wilcoxon = wilcoxon_signed_rank(errors_a, errors_b)
    if W is not None:
        print(f"Wilcoxon (scratch) | W={W:.4f} | p={p_wilcoxon:.4f} | "
              f"H0 {'rejected' if p_wilcoxon <= ALPHA else 'not rejected'}")

    # ----------------------------------------------------------
    # Part (b) -- Validate + corrected resampled t-test
    # ----------------------------------------------------------

    # TODO: Validate against scipy.stats.wilcoxon
    W_scipy = None
    p_scipy = None
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE (call scipy and compare)




    # =================================================================
    # ----------------------------------------------------------------

    t_stat, p_t = corrected_resampled_t_test(errors_a, errors_b, k=5)
    if t_stat is not None:
        print(f"Corrected t-test   | t={t_stat:.4f} | p={p_t:.4f} | "
              f"H0 {'rejected' if p_t <= ALPHA else 'not rejected'}")

    # ----------------------------------------------------------------
    # Discussion (place answer in answers.pdf):
    # Q: Do the two tests agree? Why might they differ?
    # ----------------------------------------------------------------

    return W, p_wilcoxon, W_scipy, p_scipy, t_stat, p_t


# ===========================================================
# Exercise 4: Friedman Test and Nemenyi Post-hoc Test
# ===========================================================

def friedman_test(errors):
    """Friedman Test for k algorithms on n datasets.

    Parameters
    ----------
    errors : ndarray, shape (n_datasets, n_systems)

    Returns
    -------
    chi2_F : float
    p_value : float
    mean_ranks : ndarray, shape (n_systems,)
        Mean rank per system (rank 1 = best / lowest error).
    """
    n, k = errors.shape

    # TODO:
    # 1. For each dataset (row), rank the k systems; rank 1 = lowest error.
    #    Hint: apply stats.rankdata(row, method='average') to each row.
    # 2. mean_ranks[j] = mean of ranks for system j across all n datasets.
    # 3. chi2_F = 12*n / (k*(k+1)) * (sum_j mean_ranks[j]^2 - k*(k+1)^2/4)
    # 4. p_value from chi2 distribution with (k-1) degrees of freedom:
    #    stats.chi2.sf(chi2_F, df=k-1)
    chi2_F = None       # replace
    p_value = None      # replace
    mean_ranks = None   # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------

    return chi2_F, p_value, mean_ranks


def nemenyi_post_hoc(mean_ranks, n_datasets, n_systems):
    """Nemenyi post-hoc test (all pairwise q-values after Friedman).

    Parameters
    ----------
    mean_ranks : ndarray, shape (n_systems,)
    n_datasets : int
    n_systems  : int

    Returns
    -------
    Q : ndarray, shape (n_systems, n_systems)
        Upper-triangular matrix; Q[j1,j2] = q-value for pair (j1, j2), j1 < j2.
    CD : float
        Critical difference.
    """
    # q_alpha values for alpha=0.05 (Studentised range table, k groups)
    q_alpha_table = {
        2: 1.960, 3: 2.344, 4: 2.569, 5: 2.728,
        6: 2.850, 7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164
    }
    k = n_systems
    n = n_datasets

    # TODO:
    # 1. q_alpha = q_alpha_table[k]
    # 2. CD      = q_alpha * sqrt(k * (k+1) / (6 * n))
    # 3. For each pair (j1, j2) with j1 < j2:
    #    q_val = |mean_ranks[j1] - mean_ranks[j2]| / (CD / sqrt(2))
    #    Q[j1, j2] = q_val
    # (A pair is significantly different if q_val > sqrt(2).)
    Q = np.zeros((k, k))
    CD = None  # replace
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------

    return Q, CD


def exercise_4():
    """Friedman & Nemenyi Tests (3 pts)."""
    print("\n" + "=" * 60)
    print("Exercise 4: Friedman & Nemenyi Tests")
    print("=" * 60)

    df = load_multi_system_results()
    errors = df.values          # shape (20, 5)
    system_names = df.columns.tolist()

    # ----------------------------------------------------------
    # Part (a) -- Friedman Test
    # ----------------------------------------------------------
    chi2_F, p_friedman, mean_ranks = friedman_test(errors)
    if chi2_F is not None:
        print(f"Friedman: chi2_F={chi2_F:.4f}  p={p_friedman:.4f}  "
              f"H0 {'rejected' if p_friedman <= ALPHA else 'not rejected'}")
        for name, mr in zip(system_names, mean_ranks):
            print(f"  {name}: mean rank = {mr:.3f}")

    # Skip part (b) if Friedman does not reject H0
    if chi2_F is None or p_friedman is None or p_friedman > ALPHA:
        print("H0 not rejected by Friedman -- skipping Nemenyi test.")
        return

    # ----------------------------------------------------------
    # Part (b) -- Nemenyi post-hoc + critical difference diagram
    # ----------------------------------------------------------
    n_datasets, n_systems = errors.shape
    Q, CD = nemenyi_post_hoc(mean_ranks, n_datasets, n_systems)
    if CD is not None:
        print(f"\nCritical difference CD = {CD:.4f}")
        print("Upper-triangular q-value matrix:")
        header = "       " + "  ".join(f"{s:>10}" for s in system_names)
        print(header)
        for j1 in range(n_systems):
            row_str = f"{system_names[j1]:>8} "
            for j2 in range(n_systems):
                if j2 > j1:
                    sig = "*" if Q[j1, j2] > np.sqrt(2) else " "
                    row_str += f"  {Q[j1, j2]:>8.2f}{sig}"
                else:
                    row_str += "           "
            print(row_str)

    # TODO: Produce a critical difference (CD) diagram.
    #       Option A (easiest): install autorank (pip install autorank) and use
    #           from autorank import autorank, plot_stats
    #           result = autorank(df, alpha=0.05, verbose=False)
    #           plot_stats(result)
    #       Option B: draw a simple CD bar manually with matplotlib.
    #       Save to figures/critical_difference.pdf.
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------
    print("  -> figures/critical_difference.pdf (TODO: implement above)")

    # Note which pairs differ significantly (q > sqrt(2)):
    # TODO: Print the names of significantly different pairs.
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------

    return (chi2_F, p_friedman, mean_ranks), (Q, CD)

# ===========================================================
# Exercise 5: Anytime Performance Curves
# ===========================================================

def make_step_function(times, values, grid):
    """Convert improvement events to a right-continuous step function on grid.

    Parameters
    ----------
    times  : array-like, shape (n_events,), sorted improvement wall-clock times
    values : array-like, shape (n_events,), incumbent error at each event
    grid   : array-like, shape (G,), evaluation points (must cover [0, t_max])

    Returns
    -------
    step_values : ndarray, shape (G,)
        Incumbent error at each grid point.
        Before the first event the initial value (values[0]) is used.
    """
    times = np.asarray(times, dtype=float)
    values = np.asarray(values, dtype=float)
    grid = np.asarray(grid, dtype=float)

    # TODO: For each grid point g, find the latest event time <= g and
    #       return the corresponding value.
    #       If no event has occurred yet (g < times[0]), return values[0].
    #       Hint: np.searchsorted(times, g, side='right') - 1
    step_values = np.full(len(grid), values[0])  # placeholder
    # ----------------------------------------------------------------
    # =================================================================
    # YOUR CODE HERE




    # =================================================================
    # ----------------------------------------------------------------

    return step_values


def exercise_5():
    """Anytime Performance Curves (3 pts)."""
    print("\n" + "=" * 60)
    print("Exercise 5: Anytime Performance Curves")
    print("=" * 60)

    df = load_anytime_logs()
    t_max = df["wall_time"].max()
    grid = np.linspace(0, t_max, 200)
    systems = ["A", "B"]
    seeds = sorted(df["seed"].unique())

    # ----------------------------------------------------------
    # Part (a) -- Individual step-function curves
    # ----------------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(10, 4), sharey=True)

    curves = {sys: [] for sys in systems}  # store step functions for part (b)

    for ax, sys in zip(axes, systems):
        sub = df[df["system"] == sys]
        for seed in seeds:
            run = sub[sub["seed"] == seed].sort_values("wall_time")
            times = run["wall_time"].values
            vals = run["incumbent_error"].values

            # TODO: Call make_step_function(times, vals, grid) to get the
            #       step function for this run.
            #       Plot it with ax.step(grid, step_vals, where='post',
            #           color='steelblue', alpha=0.3, linewidth=0.8).
            #       Store step_vals in curves[sys].
            # ----------------------------------------------------------------
            # =================================================================
            # YOUR CODE HERE




            # =================================================================
            # ----------------------------------------------------------------
            step_vals = make_step_function(times, vals, grid)
            curves[sys].append(step_vals)
            # ------------------------------------------------------------

        ax.set_title(f"System {sys} -- individual runs")
        ax.set_xlabel("Wall time (s)")
        ax.set_ylabel("Incumbent error")

    fig.tight_layout()
    fig.savefig("figures/anytime_individual.pdf", bbox_inches="tight")
    plt.close(fig)
    print("  -> figures/anytime_individual.pdf saved.")

    # ----------------------------------------------------------
    # Part (b) -- Aggregated mean + SE bands, log time axis
    # ----------------------------------------------------------
    fig, ax = plt.subplots(figsize=(8, 4))

    for sys in systems:
        # TODO: Stack curves[sys] into an (n_seeds, len(grid)) array.
        #       Compute pointwise mean and SE = std / sqrt(n_seeds).
        #       Plot the mean with ax.step(grid, mean, where='post', label=...).
        #       Shade mean ± SE with ax.fill_between(grid, mean-se, mean+se, alpha=0.25).
        #       Use ax.set_xscale("log").
        # ------------------------------------------------------------
        mat = np.array(curves[sys])   # shape (n_seeds, len(grid))
        mean_curve = None   # replace with np.mean(mat, axis=0)
        se_curve = None     # replace with np.std(mat, axis=0, ddof=1) / np.sqrt(len(seeds))
        # ----------------------------------------------------------------
        # =================================================================
        # YOUR CODE HERE




        # =================================================================
        # ----------------------------------------------------------------

    ax.set_xscale("log")
    ax.set_xlabel("Wall time (s) [log scale]")
    ax.set_ylabel("Mean incumbent error")
    ax.set_title("Aggregated anytime curves with SE bands")
    ax.legend()
    fig.tight_layout()
    fig.savefig("figures/anytime_aggregated.pdf", bbox_inches="tight")
    plt.close(fig)
    print("  -> figures/anytime_aggregated.pdf saved.")

    # ----------------------------------------------------------------
    # Discussion (place answer in answers.pdf):
    # Q1: At what time budget, if any, does one system dominate?
    #     Does the conclusion change at different budgets?
    # Q2: Why should SE bands be used rather than SD bands when comparing methods?
    # ----------------------------------------------------------------


# ===========================================================
# Main entry point
# ===========================================================

if __name__ == "__main__":
    exercise_1()
    exercise_2()
    exercise_3()
    exercise_4()
    exercise_5()