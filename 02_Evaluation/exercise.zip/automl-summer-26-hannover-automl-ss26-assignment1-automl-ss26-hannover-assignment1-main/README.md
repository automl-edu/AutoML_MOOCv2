# Assignment 1: Evaluation and Benchmarking


## Setup

> We assume python version 3.13 or above.

Install dependencies into a virtual environment (e.g. using *astral uv*):
```bash
# assuming venv is activated:
pip install uv  # install uv (assuming not installed)
uv sync  # to install dependencies from pyproject.toml
```


## Write your code

Write your code in **main.py**.

Run your solution with:
```bash
python main.py
# or
make run
```

You may check your code locally before submitting by running:
```bash
python -m pytest tests
# or
make test
```

Please write your answers to the questions in a pdf called **answers.pdf** (e.g. using latex or markdown to pdf, etc.). Please write your name(s) in the pdf.


## Submission

To submit, please create a commit and push your **code**, **plots**, and your **answers.pdf** file. You may push your code as many times as you want before the deadline so don't worry about pushing unfinished code, only the last push counts.
Autograding will run in GitHub Classroom when you push your code. We will also manually check your code, and the tests are mostly for your own sake. After the deadline, you will lose access to your repositories, so make sure to **push your final changes before the deadline**.

You may provide feedback to us regarding the assignment by writing in the **feedback.md** file :)
