import re

from pytest import approx
import os
from main import exercise_1, exercise_2, exercise_3, exercise_4

# ---------------------------------------------------------------------------
# NOTE: DO NOT CHANGE THIS FILE
# (it will be flagged in GitHub Classroom if this file is committed).
# ---------------------------------------------------------------------------


def test_exercise_0():
    """
    Expected format (in members.txt):
    member 1: name1
    member 2: name2
    ...
    """
    assert os.path.exists("members.txt")
    with open("members.txt", "r") as f:
        regex = r"^member\s+\d+:\s+.+$"
        for line in f:
            assert re.match(regex, line.strip()), f"Line '{line.strip()}' does not match the required format."

def test_exercise_1():
    (holdout_mean, holdout_std), (cv5_mean, cv5_std), (mccv_mean, mccv_std) = exercise_1()

    assert holdout_mean == approx(0.2800, abs=1e-3)
    assert holdout_std == approx(0.0000, abs=1e-3)

    assert cv5_mean == approx(0.3200, abs=1e-3)
    assert cv5_std == approx(0.0261, abs=1e-3)

    assert mccv_mean == approx(0.2873, abs=1e-3)
    assert mccv_std == approx(0.0416, abs=1e-3)

def test_exercise_2():
    val_bests, test_bests, bias = exercise_2()

    assert val_bests == approx([0.2875, 0.0494, 0.0494, 0.0494, 0.0494, 0.0494, 0.0300], abs=1e-3)
    assert test_bests == approx([0.2818, 0.1001, 0.1001, 0.1001, 0.1001, 0.1001, 0.1216], abs=1e-3)
    assert bias == approx(0.0917, abs=1e-3)

def test_exercise_3():
    W, p_wilcoxon, W_scipy, p_scipy, t_stat, p_t = exercise_3()

    assert W == approx(42.0000, abs=1e-3)
    assert p_wilcoxon == approx(0.0001, abs=1e-3)
    assert W_scipy == approx(42.0000, abs=1e-3)
    assert p_scipy == approx(0.0001, abs=1e-3)
    assert t_stat == approx(-5.2413, abs=1e-3)
    assert p_t == approx(0.0000, abs=1e-3)

def test_exercise_4():
    (chi2_F, p_value, mean_ranks), (Q, CD) = exercise_4()

    assert chi2_F == approx(68.1200, abs=1e-3)
    assert p_value == approx(0.0000, abs=1e-3)
    assert mean_ranks[0] == approx(1.050, abs=1e-3)
    assert mean_ranks[1] == approx(2.200, abs=1e-3)
    assert mean_ranks[2] == approx(3.100, abs=1e-3)
    assert mean_ranks[3] == approx(3.800, abs=1e-3)
    assert mean_ranks[4] == approx(4.850, abs=1e-3)

    assert CD == approx(1.2845, abs=1e-3)
    assert Q[0] == approx([0.0000, 1.2661, 2.2570, 3.0277, 4.1837], abs=1e-3)
    assert Q[1] == approx([0.0000, 0.0000, 0.9909, 1.7616, 2.9176], abs=1e-3)
    assert Q[2] == approx([0.0000, 0.0000, 0.0000, 0.7707, 1.9267], abs=1e-3)
    assert Q[3] == approx([0.0000, 0.0000, 0.0000, 0.0000, 1.1560], abs=1e-3)
    assert Q[4] == approx([0.0000, 0.0000, 0.0000, 0.0000, 0.000], abs=1e-3)

    